package bitcamp.java89.ems2.servlet.todo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bitcamp.java89.ems2.dao.StudentDao;
import bitcamp.java89.ems2.dao.TodoDao;
import bitcamp.java89.ems2.dao.impl.StudentMysqlDao;
import bitcamp.java89.ems2.domain.Student;
import bitcamp.java89.ems2.domain.Todo;

@WebServlet("/todo/detail")
public class TodoDetailServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws ServletException, IOException {
    try {
      int todoNo = Integer.parseInt(request.getParameter("todoNo"));
      
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
  
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<meta charset='UTF-8'>");
      out.println("<title>할일정보-상세정보</title>");
      out.println("</head>");
      out.println("<body>");
      
      // HeaderServlet에게 머리말 HTML 생성을 요청한다.
      RequestDispatcher rd = request.getRequestDispatcher("/header");
      rd.include(request, response);
      
      out.println("<h1>할일 정보</h1>");
      out.println("<form action='update' method='POST'>");
    
      TodoDao todoDao = (TodoDao)this.getServletContext().getAttribute("todoDao");
      Todo todo = todoDao.getOne(todoNo);
      
      if (todo == null) {
        throw new Exception("해당 학생이 없습니다.");
      }
      
      out.println("<table border='1'>");
      out.printf("<tr><th>회원 이름</th><td>"
          + "<input name='name' type='text' value='%s'></td></tr>\n", 
          todo.getName());
      out.printf("<tr><th>할일 순서</th><td>"
          + "<input name='sequence' type='text' value='%d'></td></tr>\n",
          todo.getSequence());
      out.printf("<tr><th>할일 내용</th><td>"
          + "<input name='contents' type='text' value='%s'></td></tr>\n", 
          todo.getContents());
      
      out.printf("<tr><th>상태</th><td>");
      out.println("<select name='stat'>");
      out.printf("  <option value='검토중' %s>검토중</option>\n", "검토중".equals(todo.getState()) ? "selected" : "");
      out.printf("  <option value='계획중' %s>계획중</option>\n", "계획중".equals(todo.getState()) ? "selected" : "");
      out.printf("  <option value='진행중' %s>진행중</option>\n", "진행중".equals(todo.getState()) ? "selected" : "");
      out.printf("  <option value='취소' %s>취소</option>\n", "취소".equals(todo.getState()) ? "selected" : "");
      out.printf("  <option value='진행완료' %s>진행완료</option>\n", "진행완료".equals(todo.getState()) ? "selected" : "");
      out.println("</select>");
      out.println("</td></tr>");
      out.printf("<tr><th>상태 설정일</th><td>"
          + "<input name='stateDate' type='date' value='%s'></td></tr>\n", 
          todo.getStateDate());
      out.println("</table>");
      
      out.println("<button type='submit'>변경</button>");
      out.printf(" <a href='delete?todoNo=%d'>삭제</a>\n", todo.getTodoNo());
      out.printf("<input type='hidden' name='todoNo' value='%d'>\n", todo.getTodoNo());
      
      out.println(" <a href='list'>목록</a>");
      out.println("</form>");
      
      // FooterServlet에게 꼬리말 HTML 생성을 요청한다.
      rd = request.getRequestDispatcher("/footer");
      rd.include(request, response);
      
      out.println("</body>");
      out.println("</html>");
      
    } catch (Exception e) {
      RequestDispatcher rd = request.getRequestDispatcher("/error");
      rd.forward(request, response);
      return;
    }
    
  }
  
  
}
