package bitcamp.java89.ems2.domain;

public class TeacherPic extends Teacher{
  private static final long serialVersionUID = 1L;
  
  protected int TeacherPicNo;
  
  public int getTeacherPicNo() {
    return TeacherPicNo;
  }
  public void setTeacherPicNo(int teacherPicNo) {
    TeacherPicNo = teacherPicNo;
  }

  
  
}
