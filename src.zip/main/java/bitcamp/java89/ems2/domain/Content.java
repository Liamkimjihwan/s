package bitcamp.java89.ems2.domain;

public class Content extends Member{
  private static final long serialVersionUID = 1L;
  
  protected int cono;
   protected String rdate;
   protected String vwcnt;
   
   
  public int getCono() {
    return cono;
  }
  public void setCono(int cono) {
    this.cono = cono;
  }
  public String getRdate() {
    return rdate;
  }
  public void setRdate(String rdate) {
    this.rdate = rdate;
  }
  public String getVwcnt() {
    return vwcnt;
  }
  public void setVwcnt(String vwcnt) {
    this.vwcnt = vwcnt;
  }
   
   
}
