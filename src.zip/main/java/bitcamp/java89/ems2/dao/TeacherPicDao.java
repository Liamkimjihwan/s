package bitcamp.java89.ems2.dao;

import java.util.ArrayList;

import bitcamp.java89.ems2.domain.Teacher;
import bitcamp.java89.ems2.domain.TeacherPic;

public interface TeacherPicDao {
//  boolean exist(int memberNo) throws Exception;
//  ArrayList<TeacherPic> getList() throws Exception;
//  boolean exist(String email) throws Exception;
  void insert(TeacherPic teacherPic) throws Exception;
//  Teacher getOne(int memberNo) throws Exception;
//  void update(TeacherPic teacherPic) throws Exception;
//  void delete(int memberNo) throws Exception;
  
}
