package bitcamp.java89.ems2.dao;

import java.util.ArrayList;

import bitcamp.java89.ems2.domain.Todo;

public interface TodoDao {
  ArrayList<Todo> getList() throws Exception;
  boolean exist(int sequence) throws Exception;
  public boolean exist(String email) throws Exception;
  public void insert(Todo todo) throws Exception;
  public Todo getOne(int todoNo) throws Exception;
//  public void update(Todo todo) throws Exception;
//  public void delete(int memberNo) throws Exception;
}
